#pragma once

#include <math.h>
#include "program.hpp"

unsigned int createBoardVAO();
